public interface HacerRuido {
    public void hacerRuido();
}
