public class Gato extends Animal{
    public Gato(String nombre, int numeroPatas, int peso) {
        super(nombre, numeroPatas, peso);
    }
}
