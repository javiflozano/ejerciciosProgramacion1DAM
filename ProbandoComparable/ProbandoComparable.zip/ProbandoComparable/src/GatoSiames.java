public class GatoSiames extends Gato{
    public GatoSiames(String nombre, int numeroPatas, int peso) {
        super(nombre, numeroPatas, peso);
    }
}
