public class Perro extends Animal{
    public Perro(String nombre, int numeroPatas, int peso) {
        super(nombre, numeroPatas, peso);
    }
}
